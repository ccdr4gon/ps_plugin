# 调色盘 Color Palette - CEP 版

这个目录是从原 UXP 插件移植出来的 CEP 面板版本。

## 产物

可拖拽的 CEP 扩展文件夹：

```text
cep/com.ccd.colorpalette.cep/
```

已签名安装包：

```text
cep/color-palette-signed.zxp
```

目录里包含：

```text
com.ccd.colorpalette.cep/
├── CSXS/manifest.xml       CEP 扩展清单
├── index.html              面板结构
├── styles.css              面板样式
├── main.js                 取色器、滑块、CEP 通信
├── lib/CSInterface.js      CEP evalScript 最小桥接
└── jsx/colorPalette.jsx    Photoshop ExtendScript 前景色读写
```

## 安装到这台 Photoshop 2026

CEP 面板不会从普通 `Plug-ins` 根目录扫描。建议安装到用户级 CEP 目录：

```text
C:\Users\ccdragon\AppData\Roaming\Adobe\CEP\extensions
```

如果这版 Photoshop 强制要求签名，优先使用已签名包安装脚本：

```text
cep/install-signed-to-appdata.ps1
```

脚本会把 `color-palette-signed.zxp` 解包到用户级 `extensions` 目录。也可以手动把已签名 ZXP 解压到：

```text
C:\Users\ccdragon\AppData\Roaming\Adobe\CEP\extensions\com.ccd.colorpalette.cep
```

然后重启 Photoshop。
打开位置通常是：

```text
窗口 > 扩展（旧版） > 调色盘
```

未签名开发版也可以用脚本安装，右键用 PowerShell 运行：

```text
cep/install-to-photoshop-2026.ps1
```

脚本会复制扩展到用户级 `Adobe\CEP\extensions`，停用 Photoshop 安装目录 `Required\CEP\extensions` 里的同名副本，并给常见 CSXS 版本打开 `PlayerDebugMode`。如果 Photoshop 仍提示“无法加载，因为未经正确签署”，请改用上面的签名版安装脚本。

## 兼容说明

- 前端保留 UXP 版的色环、方形 HSV 取色器、RGB/HSV 滑块和色块操作。
- UXP 的 `require("photoshop")` / `batchPlay` 已替换为 CEP 的 `CSInterface.evalScript()`。
- Photoshop 侧由 `jsx/colorPalette.jsx` 使用 ExtendScript 的 `app.foregroundColor` 读取和写入前景色。
- 在浏览器里直接打开 `index.html` 可以预览界面；没有 CEP 桥接时只跳过写入 Photoshop 的动作。
